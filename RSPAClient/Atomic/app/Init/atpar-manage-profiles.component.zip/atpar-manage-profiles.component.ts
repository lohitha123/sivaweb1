﻿import { Component } from '@angular/core';
import { TextboxControl } from '../Common/DynamicControls/TextboxControl';
import { DropDownControl } from '../Common/DynamicControls/DropDownControl';

@Component({
    moduleId: module.id,
    templateUrl: 'atpar-manage-profiles.component.html'
})

export class ManageProfilesComponent {
    content: boolean = false;
    display: boolean = false;
    display2: boolean = false;
    display3: boolean = false;
    page: boolean = true;
    go() {
        this.content = true;
    }

    create() {
        this.content = true;
    }
    popup() {
        this.display = true;
        this.display2 = false;
        this.display3 = false;
        this.page = false;
        this.content = false;
    }
    popup2() {
        this.display2 = true;
        this.display = false;
        this.display3 = false;
        this.page = false;
        this.content = false;
    }
    popup3() {
        this.display3 = true;
        this.display2 = false;
        this.display = false;
        this.page = false;
        this.content = false;
    }
    hideDialog() {
        this.page = true;
        this.display2 = false;
        this.display = false;
        this.display3 = false;
    }
}
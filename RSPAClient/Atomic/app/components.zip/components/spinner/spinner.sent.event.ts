﻿
import { PubSubEvent }    from './pub.sub.event';

export class SpinnerSentEvent extends PubSubEvent<boolean> {
    //No implementation is required
}
"use strict";
var EventBase = (function () {
    function EventBase() {
    }
    return EventBase;
}());
exports.EventBase = EventBase;
//# sourceMappingURL=event.base.js.map